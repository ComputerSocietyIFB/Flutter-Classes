package com.example.responsible_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
